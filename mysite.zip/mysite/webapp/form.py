from typing import Optional, Any

import form.py

import cgi

form = cgi.FieldStorage()
input_text = form.__getattr__("fname", "0")
input2 = form.__getattr__("lname","0")
input3 = form.__getattr__("email","0")
input4 = form.__getattr__("phoneno","0")
input5 = form.__getattr__("country","0")
input6 = form.__getattr__('city', "0")