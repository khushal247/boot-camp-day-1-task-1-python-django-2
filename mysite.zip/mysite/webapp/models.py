import psycopg2

# Create your models here.
conn = psycopg2.connect(database="testdb", user="postgres", password="123456", host="127.0.0.1", port="5432")

cur = conn.cursor()
cur.execute('''CREATE TABLE member(Firstname char(20),Lastname char(20),emailid varchar(50),phoneno int(10),country char(20),city char(20);''')

def insert new_record(self)
    new_record = ("fname","lname","email","pnoneno","country","city")
    insert_command= "Insert into member(fname,lname,email,phoneno,country,city)Values('",new_record[0]+"','"+new_record[1]+"'+new_record[2]"','"+new_record[3]"'+'"new_record[4]"'+'"new_record[5]"')"
    self.cur.execute('insert_command')

def display(self)
    self.cur.execute('Select * from members')